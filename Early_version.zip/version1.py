import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from PIL import Image, ImageTk
from datetime import datetime, timedelta
import random
##F7C172 yellow


limited_min = 0
adequate_min = 3
proficent_min = 6
comprehensive_min = 9
question_value = 1


def show_input_page():
    quiz_page.pack_forget()
    begin_page.pack(fill="both", expand=True)


drama_questions = [
    {"question": "Select all that apply to this image:", "answers": ["Triumph", "Stock Gesture", "Convention", "Technique"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Suprise", "Stock Gesture", "Convention", "Technique"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Repulsion", "Stock Gesture", "Convention", "Technique"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Mischief", "Stock Gesture", "Convention", "Technique"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Appeal", "Stock Gesture", "Convention", "Technique"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Posture", "Technique", "upright", "Presentational Acting"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Posture", "Convention", "Upright", "Presentational Acting"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Levels", "Low", "Element", "Technique"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Extension", "Stance", "Low energy", "Presentational Acting"], "correct:": 0},
    {"question": "Select all that apply to this image:", "answers": ["Stance", "Weak", "Strong", "Technique"], "correct:": 0},
]
                 
def begin_quiz():
    begin_page.pack_forget()    
    quiz_page.pack(fill="both", expand=True)

#GUI window
root = tk.Tk()

#title of the window
root.title("")

#size of the window
root.geometry("624x728+10+10")

#prevents resizing of the window
root.resizable(False, False)

begin_page = tk.Frame(root, background="#EE5361", width=624, height=728)
begin_page.pack(fill="both", expand=True)
begin_page.pack_propagate(False)

frame_line = tk.Frame(begin_page, background="black", height=2, width=557)
frame_line.place(x=34, y=16)
frame_line.pack_propagate(False)

frame_line2 = tk.Frame(begin_page, background="black", height=2, width=557)
frame_line2.place(x=34, y=20)
frame_line2.pack_propagate(False)

label_title =tk.Label(
    begin_page,    
    text="MELODRAMA",
    height="0", width="0",
    borderwidth=0, relief="sunken",
    fg= "black", bg="#EE5361",
    font = "Times 61 bold"
).place(x=34, y=22)

frame_line3 = tk.Frame(begin_page, background="black", height=2, width=557)
frame_line3.place(x=34, y=104)
frame_line3.pack_propagate(False)

frame_line4 = tk.Frame(begin_page, background="black", height=2, width=557)
frame_line4.place(x=34, y=108)
frame_line4.pack_propagate(False)

frame_line5 = tk.Frame(begin_page, background="black", height=2, width=696)
frame_line5.place(x=34, y=144)
frame_line5.pack_propagate(False)

frame_line6 = tk.Frame(begin_page, background="black", height=2, width=696)
frame_line6.place(x=34, y=148)
frame_line6.pack_propagate(False)

frame_imagebgb = tk.Frame(begin_page, background="#F7C172", height=360, width=278, borderwidth=1, highlightthickness=2 ,highlightbackground="black", highlightcolor="black")
frame_imagebgb.place(x=312, y=184)
frame_imagebgb.pack_propagate(False)

image = Image.open("entreaty.png")
image = image.resize((280, 260), Image.LANCZOS)
entreaty = ImageTk.PhotoImage(image)

label_image = tk.Label(
    frame_imagebgb,
    image = entreaty, background="#F7C172",
    width=270, height=300
)
label_image.place(x=0, y=0)

label_v1 =tk.Label(
    begin_page,    
    text="Guess the stock gesture! v1",
    height="0", width="0",
    borderwidth=0, relief="sunken",
    fg= "black", bg="#EE5361",
    font = "lexend 12"
).place(x=312, y=164)

label_answerv1 =tk.Label(
    begin_page,        
    text="Entreaty",
    height="0", width="0",
    borderwidth=0, relief="sunken",
    fg= "black", bg="#EE5361",
    font = "lexend 8"
).place(x=544, y=544)

label_whatdrama =tk.Label(
    begin_page,    
    text="What is Melodrama?",
    height="0", width="0",
    borderwidth=0, relief="sunken",
    fg= "black", bg="#EE5361",
    font = "lexend 14"
).place(x=80, y=176)

text_whatdrama =tk.Label(
    begin_page,    
    text="Melodrama is (melodrama info)",
    height="0", width="0",
    borderwidth=0, relief="sunken",
    fg= "black", bg="#EE5361",
    font = "lexend 8"
).place(x=28, y=200)

begin_button = tk.Button(begin_page, text="Begin Quiz!", height=3, width=28, highlightthickness=2 ,highlightbackground="black", highlightcolor="black",
                        font="Lexend 24 bold", bg="#F7C172", command=begin_quiz)
begin_button.place(x=38, y=560)

frame_line5 = tk.Frame(begin_page, background="black", height=2, width=557)
frame_line5.place(x=34, y=708)
frame_line5.pack_propagate(False)

frame_line8 = tk.Frame(begin_page, background="black", height=2, width=557)
frame_line8.place(x=42, y=890)
frame_line8.pack_propagate(False)

quiz_page = tk.Frame(root, background="#EE5361", width=624, height=728)
quiz_page.pack(fill="both", expand=True)
quiz_page.pack_propagate(False)

frame_line9 = tk.Frame(quiz_page, background="black", height=2, width=557)
frame_line9.place(x=34, y=16)
frame_line9.pack_propagate(False)

frame_line10 = tk.Frame(quiz_page, background="black", height=2, width=557)
frame_line10.place(x=34, y=712)
frame_line10.pack_propagate(False)

frame_imagebgq = tk.Frame(quiz_page, background="#F7C172", height=320, width=264, borderwidth=1, highlightthickness=2 ,highlightbackground="black", highlightcolor="black")
frame_imagebgq.place(x=326, y=40)
frame_imagebgq.pack_propagate(False)

label_question =tk.Label(
    quiz_page,    
    text="What is Melodrama?",
    height="0", width="0",
    borderwidth=0, relief="sunken",
    fg= "black", bg="#EE5361",
    font = "lexend 16 bold"
).place(x=40, y=40)

frame_fact = tk.Frame(quiz_page, background="#F7C172", height=280, width=264, borderwidth=1, highlightthickness=2 ,highlightbackground="black", highlightcolor="black")
frame_fact.place(x=34, y=400)
frame_fact.pack_propagate(False)

a1_button = tk.Button(quiz_page, text="Answer 1", height=2, width=32, highlightthickness=2 ,highlightbackground="black", highlightcolor="black",
                        font="Lexend 8 bold", bg="#F7C172", command=begin_quiz)
a1_button.place(x=34, y=160)

a2_button = tk.Button(quiz_page, text="Answer 2", height=2, width=32, highlightthickness=2 ,highlightbackground="black", highlightcolor="black",
                        font="Lexend 8 bold", bg="#F7C172", command=begin_quiz)
a2_button.place(x=34, y=280)

a3_button = tk.Button(quiz_page, text="Answer 3", height=2, width=32, highlightthickness=2 ,highlightbackground="black", highlightcolor="black",
                        font="Lexend 10 bold", bg="#F7C172", command=begin_quiz)
a3_button.place(x=320, y=400)

a4_button = tk.Button(quiz_page, text="Answer 4", height=2, width=32, highlightthickness=2 ,highlightbackground="black", highlightcolor="black",
                        font="Lexend 10 bold", bg="#F7C172", command=begin_quiz)
a4_button.place(x=320, y=520)

continue_button = tk.Button(quiz_page, text="skip", height=2, width=10, highlightthickness=2 ,highlightbackground="black", highlightcolor="black",
                        font="Lexend 10 bold", bg="#F7C172", command=begin_quiz)
continue_button.place(x=495, y=635)

root.mainloop()


