import tkinter as tk
from PIL import Image, ImageTk
import random


questions_per_quiz = 10      
question_value = 1            
limited_min = 0
adequate_min = 3
proficent_min = 6
comprehensive_min = 9
background_color = "#EE5361"
answer_color = "#F7C172"      
selected_color = "#FFE0B2"    
correct_color = "#8BC34A"    
wrong_color = "#E57373"        


QUESTIONS = [
    {"type": "multi", "image": "triumph.png",
     "question": "Select all that apply to this image:",
     "answers": ["Triumph", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Triumph, Triumph is a stock gesture used to celebrate victory or success.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  
     },


    {"type": "multi", "image": "surprise.png",
     "question": "Select all that apply to this image:",
     "answers": ["Surprise", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Suprise, Surprise is shown through wide eyes and a sudden, sharp movement.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  },


    {"type": "multi", "image": "repulsion.png",
     "question": "Select all that apply to this image:",
     "answers": ["Repulsion", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Repulsion, Repulsion is often shown by recoiling the body away from something.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  
     },


    {"type": "multi", "image": "mischeif.png",
     "question": "Select all that apply to this image:",
     "answers": ["Mischief", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Mischief, Mischief is often paired with a sly grin and raised eyebrows.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150 
    },


    {"type": "multi", "image": "appeal.png",
     "question": "Select all that apply to this image:",
     "answers": ["Appeal", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Appeal, Appeal is used when a character pleads or asks for help or mercy.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150 
    },


    {"type": "multi", "image": "evilsneak.png",
     "question": "Select all that apply to this image:",
     "answers": ["Posture", "Technique", "Upright", "Presentational acting"],
     "correct": [1, 2, 4],
     "fact": "Evil Sneaking, The villain often uses their posture to appear threatening.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  
     },


    {"type": "multi", "image": "heropride.png",
     "question": "Select all that apply to this image:",
     "answers": ["Posture", "Convention", "Upright", "Presentational acting"],
     "correct": [1, 3, 4],
     "fact": "Hero Pride, The hero's upright posture signals pride and courage.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150 
     },


    {"type": "multi", "image": "appeal.png",
     "question": "Select all that apply to this image:",
     "answers": ["Levels", "Low", "Element", "Technique"],
     "correct": [1, 2, 4],
     "fact": "Appeal, Using a low level can show weakness or pleading.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150 
    },


    {"type": "multi", "image": "entreaty.png",
     "question": "Select all that apply to this image:",
     "answers": ["Extension", "Stance", "Low energy", "Presentational acting"],
     "correct": [1, 2, 4],
     "fact": "Entreaty is a pleading gesture, often with an extended arm.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  
     },


    {"type": "multi", "image": "curtain.png",
     "question": "Select all that apply to the stock gesture of love", #get image
     "answers": ["Stance", "Weak", "Strong", "Technique"],
     "correct": [1, 2, 4],
     "fact": "Love is often shown through a soft, open stance.",
     "image_width": 265,
     "image_height": 335,
     "image_x": 0,
     "image_y": 0},


    {"type": "multi", "image": "curtain.png",
     "question": "Select all that apply to Tableaux", #get image
     "answers": ["Tableaux", "Aside", "Convention", "3 second hold"],
     "correct": [1, 2, 4],
     "fact": "A tableaux is a frozen picture, usually held for about 3 seconds.",
     "image_width": 265,
     "image_height": 335,
     "image_x": 0,
     "image_y": 0},


    {"type": "multi", "image": "curtain.png",
     "question": "Select all that apply to Aside",
     "answers": ["Aside", "Step toward audience", "Projection", "Low volume"],
     "correct": [1, 2, 3],
     "fact": "An aside is delivered as a step toward the audience, projected clearly.",
     "image_width": 265,
     "image_height": 335,
     "image_x": 0,
     "image_y": 0
     },


    {"type": "multi", "image": "curtain.png",
     "question": "Select all that apply to Audience interaction",
     "answers": ["Audience interaction", "Boo!", "Gasp!", "Cheer!"],
     "correct": [1, 2, 3, 4],
     "fact": "Audience interaction invites reactions like booing or cheering.",
     "image_width": 265,
     "image_height": 335,
     "image_x": 0,
     "image_y": 0  
     },


    {"type": "tf", "image": "curtain.png",
     "question": "Musical stings tell the audience how to react.",
     "correct": True,
     "fact": "A musical sting is a short burst of music used to cue the audience's reaction.",
     "image_width": 265,
     "image_height": 335,
     "image_x": 0,
     "image_y": 0
     },


    {"type": "tf", "image": "curtain.png",
     "question": "The heroine is allowed to participate in stage combat.",
     "correct": False,
     "fact": "Stage combat is usually reserved for the hero and villain, not the heroine.",
     "image_width": 265,
     "image_height": 335,
     "image_x": 0,
     "image_y": 0
     },


    {"type": "tf", "image": "curtain.png",
     "question": "Big theatre = projection and exaggeration.",
     "correct": True,
     "fact": "Bigger venues need more projection and exaggerated physicality to reach the back row.",
     "image_width": 265,
     "image_height": 335,
     "image_x": 0,
     "image_y": 0
     },

    {"type": "multi", "image": "madness.png",
     "question": "Select all that apply to this image:",
     "answers": ["Madness", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Madness, Enter madness fun fact.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  
     },

    {"type": "multi", "image": "bashfulness.png",
     "question": "Select all that apply to this image:",
     "answers": ["Bashfulness", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Bashfulness, Enter bashfulness fun fact.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  
     },     

    {"type": "multi", "image": "ridicule.png",
     "question": "Select all that apply to this image:",
     "answers": ["Ridicule", "Stock gesture", "Convention", "Technique"],
     "correct": [1, 2, 3],
     "fact": "Ridicule, Enter ridicule fun fact.",
     "image_width": 100,
     "image_height": 120,
     "image_x": 80,
     "image_y": 150  
     },       
]


root = tk.Tk()
root.title("")
root.geometry("624x728+10+10")
root.resizable(False, False)


quiz_questions = []        
current_question_number = 0  
final_score = 0                


selected_answer_1 = False  
selected_answer_2 = False
selected_answer_3 = False
selected_answer_4 = False
selected_tf_answer = None    
question_has_been_answered = False  
quiz_photo = None            
current_picture_label = None  


begin_page = tk.Frame(root, background=background_color, width=624, height=728)


tk.Frame(begin_page, background="black", height=2, width=557).place(x=34, y=16)
tk.Frame(begin_page, background="black", height=2, width=557).place(x=34, y=20)


tk.Label(begin_page, text="MELODRAMA", fg="black", bg=background_color,
         font="Times 61 bold").place(x=34, y=22)


tk.Frame(begin_page, background="black", height=2, width=557).place(x=34, y=104)
tk.Frame(begin_page, background="black", height=2, width=557).place(x=34, y=108)
tk.Frame(begin_page, background="black", height=2, width=557).place(x=34, y=144)
tk.Frame(begin_page, background="black", height=2, width=557).place(x=34, y=148)


frame_imagebgb = tk.Frame(begin_page, background=answer_color, height=360, width=278,
                           borderwidth=1, highlightthickness=2,
                           highlightbackground="black", highlightcolor="black")
frame_imagebgb.place(x=312, y=184)


image = Image.open("entreaty.png")
image = image.resize((250, 260), Image.LANCZOS)
entreaty = ImageTk.PhotoImage(image)


label_image = tk.Label(
    frame_imagebgb,
    image=entreaty, background=answer_color,
    width=260, height=350
)
label_image.place(x=0, y=0)


tk.Label(begin_page, text="Guess the stock gesture! v1", fg="black", bg=background_color,
         font="lexend 12").place(x=312, y=160)




tk.Label(begin_page, text="ʎʇɐǝɹʇuƎ", fg="black", bg=answer_color, 
         font="lexend 8").place(x=540, y=522)


tk.Label(begin_page, text="Instructions", fg="black", bg=background_color,
         font="lexend 14").place(x=110, y=176)


tk.Label(begin_page, text="This is a quiz about Melodrama. There are 10 questions of multiple choice and True/False variety. Multiple choice questions have 2-4 correct answers in each question. All correct answers must be selected for a point. Skipping the question will result in no points gained, you cannot go back questions. The scoring is as follows:\n Limited: 0-2\nAdequate: 3-5\nProficent: 6-8\nComprehensive: 9-10  ", fg="black", bg=background_color, wraplength=260,
         font="lexend 12").place(x=28, y=200)


tk.Frame(begin_page, background="black", height=2, width=557).place(x=34, y=708)
quiz_page = tk.Frame(root, background=background_color, width=624, height=728)


question_count_label = tk.Label(
    quiz_page, text="", fg=background_color, bg=answer_color,
    font="Lexend 10 bold", highlightthickness=2,
    highlightbackground="black", highlightcolor="black"
)
question_count_label.place(x=526, y=22, width=58, height=32)


tk.Frame(quiz_page, background="black", height=2, width=557).place(x=34, y=16)
tk.Frame(quiz_page, background="black", height=2, width=557).place(x=34, y=712)


label_question = tk.Label(quiz_page, text="", fg="black", bg=background_color,
                           font="lexend 16 bold", wraplength=260, justify="left")
label_question.place(x=40, y=40, width=260)


image_frame_x = 320
image_frame_y = 60
image_frame_width = 264
image_frame_height = 330

frame_imagebgq = tk.Frame(quiz_page, background=answer_color, height=image_frame_height, width=image_frame_width,
                           borderwidth=1, highlightthickness=2,
                           highlightbackground="black", highlightcolor="black")
frame_imagebgq.place(x=image_frame_x, y=image_frame_y)


stage_image = Image.open("stage.png")
stage_image = stage_image.resize((260, 320), Image.LANCZOS)
stage_photo = ImageTk.PhotoImage(stage_image)

stage_label = tk.Label(quiz_page, image=stage_photo, background=answer_color)
stage_label.place(x=image_frame_x + 2, y=image_frame_y + 2, width=260, height=320)
stage_label.lift(frame_imagebgq)


frame_fact = tk.Frame(quiz_page, background=answer_color, height=280, width=264, 
                       borderwidth=1, highlightthickness=2,
                       highlightbackground="black", highlightcolor="black")
frame_fact.place(x=34, y=400)


tk.Label(frame_fact, text="Fun fact!", background=answer_color, font="lexend 8").place(x=8, y=6)


fact_text_label = tk.Label(frame_fact, text="", background=answer_color, font="lexend 15 bold",
                            wraplength=240, justify="center")
fact_text_label.place(x=8, y=20, width=244, height=170)


answer_button_1 = tk.Button(quiz_page, font="Lexend 10 bold", bg=answer_color,
                             highlightthickness=2, highlightbackground="black",
                             highlightcolor="black", wraplength=240,
                             command=lambda: None)
answer_button_2 = tk.Button(quiz_page, font="Lexend 10 bold", bg=answer_color,
                             highlightthickness=2, highlightbackground="black",
                             highlightcolor="black", wraplength=240,
                             command=lambda: None)
answer_button_3 = tk.Button(quiz_page, font="Lexend 10 bold", bg=answer_color,
                             highlightthickness=2, highlightbackground="black",
                             highlightcolor="black", wraplength=240,
                             command=lambda: None)
answer_button_4 = tk.Button(quiz_page, font="Lexend 10 bold", bg=answer_color,
                             highlightthickness=2, highlightbackground="black",
                             highlightcolor="black", wraplength=240,
                             command=lambda: None)


true_button = tk.Button(quiz_page, text="True", font="Lexend 22 bold", bg=answer_color,
                         highlightthickness=2, highlightbackground="black",
                         highlightcolor="black")
false_button = tk.Button(quiz_page, text="False", font="Lexend 22 bold", bg=answer_color,
                          highlightthickness=2, highlightbackground="black",
                          highlightcolor="black")


skip_next_button = tk.Button(quiz_page, text="Skip", height=2, width=10,
                              highlightthickness=2, highlightbackground="black",
                              highlightcolor="black", font="Lexend 10 bold", bg=answer_color)
skip_next_button.place(x=495, y=635)


answer_feedback_label = tk.Label(
    quiz_page, text="", bg=answer_color,
    highlightthickness=1, highlightbackground="black",
    highlightcolor="black",
    font="Lexend 20 bold" 
)
answer_feedback_label.place(x=425, y=644, width=60, height=25)


results_page = tk.Frame(root, background=background_color, width=624, height=728)
tk.Frame(results_page, background="black", height=2, width=557).place(x=34, y=712)
tk.Frame(results_page, background="black", height=2, width=557).place(x=34, y=16)


tk.Label(results_page, text="Breaking News!", fg="black", bg=background_color,
         font="Times 44 bold").place(relx=0.5, y=20, anchor="n")


result_title_label = tk.Label(results_page, text="", fg="black", bg=background_color,
                              font="lexend 18 bold")
result_title_label.place(relx=0.5, y=84, anchor="n")


frame_minigame = tk.Frame(results_page, background=answer_color, height=280, width=270,
                           borderwidth=1, highlightthickness=2,
                           highlightbackground="black", highlightcolor="black")
frame_minigame.place(x=24, y=130)


tk.Label(results_page, text="You unlocked a minigame!", fg="black", bg=background_color,
         font="lexend 9").place(x=24, y=414, width=270)


tk.Label(results_page, text="How many questions did\nthe player get right?",
         fg="black", bg=background_color, font="lexend 16 bold",
         justify="left").place(x=24, y=442, width=270)


result_score_label = tk.Label(results_page, text="", fg="black", bg=background_color,
                               font="lexend 12", wraplength=270, justify="left")
result_score_label.place(x=24, y=496, width=270, height=150)


tk.Label(results_page, text="List of answers", fg="black", bg=background_color,
         font="lexend 16 bold").place(x=326, y=118)


frame_answer_list = tk.Frame(results_page, background=answer_color, height=540, width=274,
                              borderwidth=1, highlightthickness=2,
                              highlightbackground="black", highlightcolor="black")
frame_answer_list.place(x=326, y=150)


retry_button = tk.Button(results_page, text="Retry", font="Lexend 16 bold", bg=answer_color,
                          highlightthickness=2, highlightbackground="black",
                          highlightcolor="black", command=lambda: begin_quiz())
retry_button.place(x=24, y=656, width=130, height=48)


exit_button = tk.Button(results_page, text="Exit", font="Lexend 16 bold", bg=answer_color,
                         highlightthickness=2, highlightbackground="black",
                         highlightcolor="black", command=root.destroy)
exit_button.place(x=164, y=656, width=130, height=48)
begin_page.place(x=0, y=0, width=624, height=728)


def show_question_image(question):
    global quiz_photo, current_picture_label


    if current_picture_label is not None:
        current_picture_label.destroy()


    filename = question["image"]

    image_width = question.get("image_width", 260)
    image_height = question.get("image_height", 300)

    try:
        picture = Image.open(filename)
        picture = picture.resize((image_width, image_height), Image.LANCZOS)
        quiz_photo = ImageTk.PhotoImage(picture)
    except Exception as error:
        print(f"Warning: couldn't load image '{filename}' for this question: {error}")
        quiz_photo = None
        current_picture_label = None
        return

    default_x = (image_frame_width - image_width) // 2
    default_y = (image_frame_height - image_height) // 2
    inside_box_x = question.get("image_x", default_x)
    inside_box_y = question.get("image_y", default_y)

    page_x = image_frame_x + inside_box_x
    page_y = image_frame_y + inside_box_y

    current_picture_label = tk.Label(quiz_page, image=quiz_photo, background=answer_color)
    current_picture_label.place(x=page_x, y=page_y, width=image_width, height=image_height)

    current_picture_label.lift()


def show_multi_choice_buttons(question):
    answer_button_1.config(text=question["answers"][0], command=answer_1_clicked, state="normal")
    answer_button_2.config(text=question["answers"][1], command=answer_2_clicked, state="normal")
    answer_button_3.config(text=question["answers"][2], command=answer_3_clicked, state="normal")
    answer_button_4.config(text=question["answers"][3], command=answer_4_clicked, state="normal")
    answer_button_1.config(bg=answer_color)
    answer_button_2.config(bg=answer_color)
    answer_button_3.config(bg=answer_color)
    answer_button_4.config(bg=answer_color)
    answer_button_1.place(x=34, y=160, width=264, height=105)
    answer_button_2.place(x=34, y=285, width=264, height=105)
    answer_button_3.place(x=320, y=401, width=264, height=100)
    answer_button_4.place(x=320, y=511, width=264, height=100)
    true_button.place_forget()
    false_button.place_forget()


def show_true_false_buttons():
    true_button.config(command=true_clicked, state="normal", bg=answer_color)
    false_button.config(command=false_clicked, state="normal", bg=answer_color)
    true_button.place(x=34, y=160, width=264, height=230)
    false_button.place(x=320, y=400, width=264, height=210)


    answer_button_1.place_forget()
    answer_button_2.place_forget()
    answer_button_3.place_forget()
    answer_button_4.place_forget()


def load_question(question_number):
    global current_question_number
    global selected_answer_1, selected_answer_2, selected_answer_3, selected_answer_4
    global selected_tf_answer, question_has_been_answered


    current_question_number = question_number
    question = quiz_questions[question_number]
    question_count_label.config(
        text=str(question_number + 1) + "/" + str(questions_per_quiz)
    )
    answer_feedback_label.config(text="", fg=background_color)


    selected_answer_1 = False
    selected_answer_2 = False
    selected_answer_3 = False
    selected_answer_4 = False
    selected_tf_answer = None
    question_has_been_answered = False


    label_question.config(text=question["question"])
    show_question_image(question)
    fact_text_label.config(text="")


    if question["type"] == "multi":
        show_multi_choice_buttons(question)
    else:
        show_true_false_buttons()


    skip_next_button.config(text="Skip", command=skip_next_clicked, state="normal")


def has_made_a_selection():
    question = quiz_questions[current_question_number]
    if question["type"] == "multi":
        return selected_answer_1 or selected_answer_2 or selected_answer_3 or selected_answer_4
    else:
        return selected_tf_answer is not None


def update_skip_next_button_text():
    if question_has_been_answered:
        return
    if has_made_a_selection():
        skip_next_button.config(text="Next")
    else:
        skip_next_button.config(text="Skip")


def answer_1_clicked():
    global selected_answer_1
    if question_has_been_answered:
        return
    if selected_answer_1:
        selected_answer_1 = False
        answer_button_1.config(bg=answer_color)
    else:
        selected_answer_1 = True
        answer_button_1.config(bg=selected_color)
    update_skip_next_button_text()


def answer_2_clicked():
    global selected_answer_2
    if question_has_been_answered:
        return
    if selected_answer_2:
        selected_answer_2 = False
        answer_button_2.config(bg=answer_color)
    else:
        selected_answer_2 = True
        answer_button_2.config(bg=selected_color)
    update_skip_next_button_text()


def answer_3_clicked():
    global selected_answer_3
    if question_has_been_answered:
        return
    if selected_answer_3:
        selected_answer_3 = False
        answer_button_3.config(bg=answer_color)
    else:
        selected_answer_3 = True
        answer_button_3.config(bg=selected_color)
    update_skip_next_button_text()


def answer_4_clicked():
    global selected_answer_4
    if question_has_been_answered:
        return
    if selected_answer_4:
        selected_answer_4 = False
        answer_button_4.config(bg=answer_color)
    else:
        selected_answer_4 = True
        answer_button_4.config(bg=selected_color)
    update_skip_next_button_text()


def true_clicked():
    global selected_tf_answer
    if question_has_been_answered:
        return
    selected_tf_answer = True
    true_button.config(bg=selected_color)
    false_button.config(bg=answer_color)
    update_skip_next_button_text()


def false_clicked():
    global selected_tf_answer
    if question_has_been_answered:
        return
    selected_tf_answer = False
    false_button.config(bg=selected_color)
    true_button.config(bg=answer_color)
    update_skip_next_button_text()


def evaluate_multi_choice_answer(question):
    correct_list = question["correct"]
    button_1_should_be_correct = 1 in correct_list
    button_2_should_be_correct = 2 in correct_list
    button_3_should_be_correct = 3 in correct_list
    button_4_should_be_correct = 4 in correct_list


    if button_1_should_be_correct:
        answer_button_1.config(bg=correct_color)
    elif selected_answer_1:
        answer_button_1.config(bg=wrong_color)
    answer_button_1.config(state="disabled")


    if button_2_should_be_correct:
        answer_button_2.config(bg=correct_color)
    elif selected_answer_2:
        answer_button_2.config(bg=wrong_color)
    answer_button_2.config(state="disabled")


    if button_3_should_be_correct:
        answer_button_3.config(bg=correct_color)
    elif selected_answer_3:
        answer_button_3.config(bg=wrong_color)
    answer_button_3.config(state="disabled")


    if button_4_should_be_correct:
        answer_button_4.config(bg=correct_color)
    elif selected_answer_4:
        answer_button_4.config(bg=wrong_color)
    answer_button_4.config(state="disabled")


    if selected_answer_1 != button_1_should_be_correct:
        return False
    if selected_answer_2 != button_2_should_be_correct:
        return False
    if selected_answer_3 != button_3_should_be_correct:
        return False
    if selected_answer_4 != button_4_should_be_correct:
        return False
    return True


def evaluate_true_false_answer(question):
    correct_answer = question["correct"]
    if correct_answer is True:
        true_button.config(bg=correct_color)
        if selected_tf_answer is False:
            false_button.config(bg=wrong_color)
    else:
        false_button.config(bg=correct_color)
        if selected_tf_answer is True:
            true_button.config(bg=wrong_color)
    true_button.config(state="disabled")
    false_button.config(state="disabled")
    return selected_tf_answer == correct_answer


def evaluate_answer():
    global final_score, question_has_been_answered
    question = quiz_questions[current_question_number]
    if question["type"] == "multi":
        answered_correctly = evaluate_multi_choice_answer(question)
    else:
        answered_correctly = evaluate_true_false_answer(question)
    if answered_correctly:
        final_score = final_score + question_value
        answer_feedback_label.config(text="+1", fg=correct_color)
    else:
        answer_feedback_label.config(text="+0", fg=wrong_color)
    fact_text_label.config(text=question["fact"])
    question_has_been_answered = True
    skip_next_button.config(text="Continue", state="normal")


def go_to_next_question():
    next_question_number = current_question_number + 1
    if next_question_number == questions_per_quiz:
        show_results_page()
    else:
        load_question(next_question_number)


def skip_next_clicked():
    skip_next_button.config(state="disabled")
    if question_has_been_answered:
        go_to_next_question()        
    elif has_made_a_selection():
        evaluate_answer()          
    else:
        go_to_next_question()        


def show_results_page():
    quiz_page.place_forget()


    total_possible_score = questions_per_quiz * question_value
    if final_score >= comprehensive_min:
        score = "Comprehensive"
        score_message = "Awesome job!"
    elif final_score >= proficent_min:
        score = "Proficient"
        score_message = "Great work!"
    elif final_score >= adequate_min:
        score = "Adequate"
        score_message = "Good effort!"
    else:
        score = "Limited"
        score_message = "Better luck next time!"
    result_title_label.config(text="Your score is " + score)
    result_score_label.config(
        text="The player got " + str(final_score) + "/" + str(total_possible_score)
             + " questions right! " + score_message
    )
    results_page.place(x=0, y=0, width=624, height=728)


def begin_quiz():
    global quiz_questions, current_question_number, final_score


    quiz_questions = random.sample(QUESTIONS, questions_per_quiz)
    current_question_number = 0
    final_score = 0
    begin_page.place_forget()
    results_page.place_forget()
    quiz_page.place(x=0, y=0, width=624, height=728)
    load_question(0)


begin_button = tk.Button(begin_page, text="Begin Quiz!", height=3, width=28,
                          highlightthickness=2, highlightbackground="black",
                          highlightcolor="black", font="Lexend 24 bold", bg=answer_color,
                          command=begin_quiz)
begin_button.place(x=38, y=560)


root.mainloop()