#melodrama quiz
#18/09/2026
#Portugal, Raphael

import tkinter as tk
from PIL import Image, ImageTk
import random
from datetime import date

# quiz configuration
QUESTIONS_PER_QUIZ = 10
QUESTION_VALUE = 1

# minimum score needed to reach each score
LIMITED_MIN = 0
ADEQUATE_MIN = 3
PROFICENT_MIN = 6
COMPREHENSIVE_MIN = 9

#Colours used
BACKGROUND_COLOR = "#EE5361"
ANSWER_COLOR = "#F7C172"
SELECTED_COLOR = "#FFE0B2"
CORRECT_COLOR = "#8BC34A"
WRONG_COLOR = "#E57373"

#unchanged position and size of the image frame on the quiz page
IMAGE_FRAME_X = 320
IMAGE_FRAME_Y = 60
IMAGE_FRAME_WIDTH = 264
IMAGE_FRAME_HEIGHT = 330

#question dictionary. Every question has a type (multi choice
#and true/false), image attatched, question name for result list,
#the question asked, all answers, correct answers labeled, a fun
#fact writen, and custom image height/width and positioning.  
QUESTIONS = [
    {"type": "multi", "image": "triumph.png",
    "name": "Triumph",
    "question": "Select all that apply to this image:",
    "answers": ["Triumph", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Triumph, Triumph is a stock gesture used to "
        "celebrate victory or success.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "surprise.png",
    "name": "Surprise",
    "question": "Select all that apply to this image:",
    "answers": ["Surprise", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Suprise, Surprise is shown through wide eyes and "
        "a sudden, sharp movement.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "repulsion.png",
    "name": "Repulsion",
    "question": "Select all that apply to this image:",
    "answers": ["Repulsion", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Repulsion, Repulsion is often shown by recoiling "
        "the body away from something.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "mischief.png",
    "name": "Mischief",
    "question": "Select all that apply to this image:",
    "answers": ["Mischief", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Mischief, Mischief is often paired with a sly "
        "grin and raised eyebrows.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "appeal.png",
    "name": "Appeal",
    "question": "Select all that apply to this image:",
    "answers": ["Appeal", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Appeal, Appeal is used when a character pleads "
        "or asks for help or mercy.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "evilsneak.png",
    "name": "Evil Sneaking",
    "question": "Select all that apply to this image:",
    "answers": ["Posture", "Technique", "Upright",
        "Presentational acting"],
    "correct": [1, 2, 4],
    "fact": "Evil Sneaking, The villain often uses their "
        "posture to appear threatening.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "heropride.png",
    "name": "Hero Pride",
    "question": "Select all that apply to this image:",
    "answers": ["Posture", "Convention", "Upright",
        "Presentational acting"],
    "correct": [1, 3, 4],
    "fact": "Hero Pride, The hero's upright posture signals "
        "pride and courage.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "appeal.png",
    "name": "Levels",
    "question": "Select all that apply to this image:",
    "answers": ["Levels", "Low", "Element", "Technique"],
    "correct": [1, 2, 4],
    "fact": "Appeal, Using a low level can show weakness or "
        "pleading.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "entreaty.png",
    "name": "Entreaty",
    "question": "Select all that apply to this image:",
    "answers": ["Extension", "Stance", "Low energy",
        "Presentational acting"],
    "correct": [1, 2, 4],
    "fact": "Entreaty is a pleading gesture, often with an "
        "extended arm.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "curtain.png",
    "name": "Love",
    "question": "Select all that apply to the stock gesture "
        "of feminine love",
    "answers": ["Stance", "Weak", "Strong", "Technique"],
    "correct": [1, 2, 4],
    "fact": "Love is often shown through a soft, open stance.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},

    {"type": "multi", "image": "curtain.png",
    "name": "Tableaux",
    "question": "Select all that apply to Tableaux",
    "answers": ["Extension", "Aside", "Convention",
        "3 second hold"],
    "correct": [1, 3, 4],
    "fact": "A tableaux is a frozen picture, usually held for "
        "about 3 seconds.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},

    {"type": "multi", "image": "curtain.png",
    "name": "Aside",
    "question": "Select all that apply to Aside",
    "answers": ["Aside", "Step toward audience", "Projection",
        "Low volume"],
    "correct": [1, 2, 3],
    "fact": "An aside is delivered as a step toward the "
        "audience, projected clearly.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},

    {"type": "multi", "image": "curtain.png",
    "name": "Audience Interaction",
    "question": "Select all that apply to Audience "
        "interaction",
    "answers": ["Audience interaction", "Boo!", "Gasp!",
        "Cheer!"],
    "correct": [1, 2, 3, 4],
    "fact": "Audience interaction invites reactions like "
        "booing or cheering.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},

    {"type": "tf", "image": "curtain.png",
    "name": "Musical Stings",
    "question": "Musical stings tell the audience how to "
        "react.",
    "correct": True,
    "fact": "A musical sting is a short burst of music used "
        "to cue the audience's reaction.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},

    {"type": "tf", "image": "curtain.png",
    "name": "Stage Combat",
    "question": "The heroine is allowed to participate in "
        "stage combat.",
    "correct": False,
    "fact": "Stage combat is usually reserved for the hero "
        "and villain, not the heroine.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},

    {"type": "tf", "image": "curtain.png",
    "name": "Big Theatre",
    "question": "Big theatre = projection and exaggeration.",
    "correct": True,
    "fact": "Bigger venues need more projection and "
        "exaggerated physicality to reach the back row.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},

    {"type": "multi", "image": "madness.png",
    "name": "Madness",
    "question": "Select all that apply to this image:",
    "answers": ["Madness", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Madness, Madness is often shown through "
        "exaggerated movements, wild expressions, and "
        "unpredictable behaviour.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "bashfulness.png",
    "name": "Bashfulness",
    "question": "Select all that apply to this image:",
    "answers": ["Bashfulness", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Bashfulness, Bashfulness is often shown by "
        "looking down, avoiding eye contact, or covering "
        "the face.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "multi", "image": "ridicule.png",
    "name": "Ridicule",
    "question": "Select all that apply to this image:",
    "answers": ["Ridicule", "Stock gesture", "Convention",
        "Technique"],
    "correct": [1, 2, 3],
    "fact": "Ridicule, Ridicule is often shown through "
        "mocking gestures, exaggerated facial "
        "expressions, or laughter.",
    "image_width": 100,
    "image_height": 120,
    "image_x": 80,
    "image_y": 150},

    {"type": "tf", "image": "curtain.png",
    "name": "Stock Gesture",
    "question": "Stock gestures are exaggerated movements "
        "that communicate emotions or ideas.",
    "correct": True,
    "fact": "Stock gestures use recognisable and exaggerated "
        "movements to communicate emotions or ideas "
        "clearly to the audience.",
    "image_width": 265,
    "image_height": 335,
    "image_x": 0,
    "image_y": 0},
]

#gui window
root = tk.Tk()

#title of the window
root.title("")

#size and positioning of the window
root.geometry("624x728+10+10")

#prevents resizing of the window
root.resizable(False, False)

# state of the quiz variables
quiz_questions = []
current_question_number = 0
final_score = 0

# current question's selections, reset each time load_question runs
selected_answer_1 = False
selected_answer_2 = False
selected_answer_3 = False
selected_answer_4 = False
selected_tf_answer = None
question_has_been_answered = False
quiz_photo = None
current_picture_label = None
answer_record = []

#Begining page creation
#creates begin page
begin_page = tk.Frame(root, background=BACKGROUND_COLOR,
    width=624, height=728)

#creates and places first 2 lines, above title
line_1 = tk.Frame(begin_page, background="black", height=2,
    width=557).place(x=34, y=16)
line_2 = tk.Frame(begin_page, background="black", height=2,
    width=557).place(x=34, y=20)

#creates and places melodrama title
title_label = tk.Label(begin_page, text="MELODRAMA", fg="black",
    bg=BACKGROUND_COLOR,
    font="Times 61 bold").place(x=34, y=22)

#creates and places 3rd and 4th line, below melodrama title
line_3 = tk.Frame(begin_page, background="black", height=2,
    width=557).place(x=34, y=104)
line_4 = tk.Frame(begin_page, background="black", height=2,
    width=557).place(x=34, y=108)

#gets current local date
today = date.today()

#creates and places the day number of the date
day_label = tk.Label(begin_page, text=today.day, fg="black",
    bg=BACKGROUND_COLOR,
    font="Times 20 bold").place(x=170, y=110)

#creates and places the month word of the date
month_label = tk.Label(begin_page, text=today.strftime("%B"), fg="black",
    bg=BACKGROUND_COLOR,
    font="Times 20 bold").place(x=230, y=110)

#creates and places the year number of the date
year_label = tk.Label(begin_page, text=today.year, fg="black",
    bg=BACKGROUND_COLOR,
    font="Times 20 bold").place(x=380, y=110)

#creates and places 5th and 6th line, below date
line_5 = tk.Frame(begin_page, background="black", height=2,
    width=557).place(x=34, y=144)
line_6 = tk.Frame(begin_page, background="black", height=2,
    width=557).place(x=34, y=148)

#creates and places background for guess the stock gesture v1 image
frame_imagebgb = tk.Frame(begin_page, background=ANSWER_COLOR,
    height=360, width=278, borderwidth=1,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black")
frame_imagebgb.place(x=312, y=184)

#gets page 1 entreaty image
image = Image.open("entreaty.png")
image = image.resize((250, 260), Image.LANCZOS)
entreaty = ImageTk.PhotoImage(image)

#adds label with image to gui
label_image = tk.Label(frame_imagebgb, image=entreaty,
    background=ANSWER_COLOR, width=260,
    height=350)
label_image.place(x=0, y=0)

#creates and places the "guess the stock gesture! v1" text
guessv1_label = tk.Label(begin_page, text="Guess the stock gesture! v1",
    fg="black", bg=BACKGROUND_COLOR,
    font="lexend 12").place(x=312, y=160)

#creates and places the upside down entreaty text
upside_entreaty_label = tk.Label(begin_page, text="ʎʇɐǝɹʇuǝ",
    fg="black",
    bg=ANSWER_COLOR,
    font="lexend 8").place(x=540, y=522)

#creates and places the "instructions" text
instructions_label = tk.Label(begin_page, text="Instructions", fg="black",
    bg=BACKGROUND_COLOR,
    font="lexend 14").place(x=110, y=176)

#creates and places the instructions explaination text
instructions_text_label = tk.Label(begin_page,
    text="This is a quiz about Melodrama. There are 10 "
        "questions of multiple choice and True/False "
        "variety. Multiple choice questions have 3-4 "
        "correct answers in each question. ALL correct "
        "answers must be selected for a point, all "
        "correct answers will always flash green after "
        "clicking next to indicate which answers are correct "
        "whether or not you answered correct correct. Skipping "
        "the question will result in no points gained, "
        "you cannot go back questions. The scoring is as "
        "follows:\n Limited: 0-2\nAdequate: 3-5\n"
        "Proficent: 6-8\nComprehensive: 9-10  ",
    fg="black", bg=BACKGROUND_COLOR, wraplength=260,
    font="lexend 12").place(x=28, y=200)

#creates and places the 7th line, bottom of the begin page
line_7 = tk.Frame(begin_page, background="black", height=2,
    width=557).place(x=34, y=708)

#quiz page creation
#creates quiz page
quiz_page = tk.Frame(root, background=BACKGROUND_COLOR,
    width=624, height=728)

#creates and places question count
question_count_label = tk.Label(
    quiz_page, text="", fg=BACKGROUND_COLOR, bg=ANSWER_COLOR,
    font="Lexend 10 bold", highlightthickness=2,
    highlightbackground="black", highlightcolor="black")
question_count_label.place(x=526, y=22, width=58, height=32)

#creates and places 8th and 9th line, placed at the top and bottom
#of the page respectively
line_8 = tk.Frame(quiz_page, background="black", height=2,
    width=557).place(x=34, y=16)
line_9 = tk.Frame(quiz_page, background="black", height=2,
    width=557).place(x=34, y=712)

#creates and places the question label
label_question = tk.Label(quiz_page, text="", fg="black",
    bg=BACKGROUND_COLOR,
    font="lexend 16 bold", wraplength=260,
    justify="left")
label_question.place(x=40, y=40, width=260)

#creates and places the frame that the question image
#is in, holds the stage, and gets covered by the curtains.
frame_imagebgq = tk.Frame(quiz_page, background=ANSWER_COLOR,
    height=IMAGE_FRAME_HEIGHT,
    width=IMAGE_FRAME_WIDTH, borderwidth=1,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black")
frame_imagebgq.place(x=IMAGE_FRAME_X, y=IMAGE_FRAME_Y)

#gets stage image
stage_image = Image.open("stage.png")
stage_image = stage_image.resize((260, 320), Image.LANCZOS)
stage_photo = ImageTk.PhotoImage(stage_image)

#adds label with image to gui
stage_label = tk.Label(quiz_page, image=stage_photo,
    background=ANSWER_COLOR)
stage_label.place(x=IMAGE_FRAME_X + 2, y=IMAGE_FRAME_Y + 2,
    width=260, height=320)
stage_label.lift(frame_imagebgq)

# fun fact panel, filled in once a question is answered
frame_fact = tk.Frame(quiz_page, background=ANSWER_COLOR,
    height=280, width=264, borderwidth=1,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black")
frame_fact.place(x=34, y=400)

#creates and places fun fact! text
funfact_label = tk.Label(frame_fact, text="Fun fact!", background=ANSWER_COLOR,
    font="lexend 15 bold").place(x=8, y=6)

#creates and places fun fact content label
fact_text_label = tk.Label(frame_fact, text="",
    background=ANSWER_COLOR,
    font="lexend 17", wraplength=240,
    justify="center")
fact_text_label.place(x=8, y=30, width=244, height=200)

#creation of multi choice answer button, the text and command and set
#depending on the question by show_multi_choice_buttons()
answer_button_1 = tk.Button(quiz_page, font="Lexend 10 bold",
    bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    wraplength=240, command=lambda: None)
answer_button_2 = tk.Button(quiz_page, font="Lexend 10 bold",
    bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    wraplength=240, command=lambda: None)
answer_button_3 = tk.Button(quiz_page, font="Lexend 10 bold",
    bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    wraplength=240, command=lambda: None)
answer_button_4 = tk.Button(quiz_page, font="Lexend 10 bold",
    bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    wraplength=240, command=lambda: None)

#true/false answer buttons creation and placement
#shown on true false questions
true_button = tk.Button(quiz_page, text="True",
    font="Lexend 22 bold", bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black")
false_button = tk.Button(quiz_page, text="False",
    font="Lexend 22 bold", bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black")

# creates and places button which changes between skip, next
# and continue
skip_next_button = tk.Button(quiz_page, text="Skip", height=2,
    width=10, highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    font="Lexend 10 bold",
    bg=ANSWER_COLOR)
skip_next_button.place(x=495, y=635)

#creates and places answer feedback label
#which indicates if the user gets +1 or -1 points
answer_feedback_label = tk.Label(
    quiz_page, text="", bg=ANSWER_COLOR,
    highlightthickness=1, highlightbackground="black",
    highlightcolor="black", font="Lexend 20 bold")
answer_feedback_label.place(x=410, y=637, width=80, height=40)

#Result page creation
#creates results page
results_page = tk.Frame(root, background=BACKGROUND_COLOR,
    width=624, height=728)

#creates and places 10th and 11th line at the top and bottom
#of the page respectivley
line_10 = tk.Frame(results_page, background="black", height=2,
    width=557).place(x=34, y=712)
line_11 = tk.Frame(results_page, background="black", height=2,
    width=557).place(x=34, y=16)

#creates and places breaking news label
breaking_news_label = tk.Label(results_page, text="Breaking News!", fg="black",
    bg=BACKGROUND_COLOR,
    font="Times 44 bold").place(relx=0.5, y=20, anchor="n")

#creates and places result title label
result_title_label = tk.Label(results_page, text="", fg="black",
    bg=BACKGROUND_COLOR,
    font="lexend 18 bold")
result_title_label.place(relx=0.5, y=84, anchor="n")

#creates and places "how many questions did the player
# get right" heading label
heading_label = tk.Label(results_page,
    text="How many questions did\nthe player get right?",
    fg="black", bg=BACKGROUND_COLOR,
    font="lexend 16 bold",
    justify="left").place(x=24, y=130, width=270)

#creates and places score results label
result_score_label = tk.Label(results_page, text="",
    fg="black", bg=BACKGROUND_COLOR,
    font="lexend 12", wraplength=270,
    justify="left")
result_score_label.place(x=24, y=180, width=270, height=150)

#creats and places list of answers text
list_answers_label = tk.Label(results_page, text="List of answers", fg="black",
    bg=BACKGROUND_COLOR,
    font="lexend 16 bold").place(x=326, y=118)

#creates and places frame for answer list
frame_answer_list = tk.Frame(results_page, background=ANSWER_COLOR,
    height=540, width=274,
    borderwidth=1,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black")
frame_answer_list.place(x=326, y=150)

#creates and places the retry button
retry_button = tk.Button(results_page, text="Retry",
    font="Lexend 16 bold", bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    command=lambda: begin_quiz())
retry_button.place(x=24, y=656, width=130, height=48)

#creates and places the exit button
exit_button = tk.Button(results_page, text="Exit",
    font="Lexend 16 bold", bg=ANSWER_COLOR,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    command=root.destroy)
exit_button.place(x=164, y=656, width=130, height=48)

#places the begin page, it is the first thing shown
begin_page.place(x=0, y=0, width=624, height=728)


def show_question_image(question):
    """Load and place the current question's image. destroys any
    previously shown image labels if any, loads, resizes, and places
    it inside image frame as directed by question data (if none given,
    use deafult)
    """
    global quiz_photo, current_picture_label

    if current_picture_label is not None:
        current_picture_label.destroy()

    filename = question["image"]

    image_width = question.get("image_width", 260)
    image_height = question.get("image_height", 300)

    try:
        picture = Image.open(filename)
        picture = picture.resize((image_width, image_height),
            Image.LANCZOS)
        quiz_photo = ImageTk.PhotoImage(picture)
    except Exception as error:
        quiz_photo = None
        current_picture_label = None
        return

    default_x = (IMAGE_FRAME_WIDTH - image_width) // 2
    default_y = (IMAGE_FRAME_HEIGHT - image_height) // 2
    inside_box_x = question.get("image_x", default_x)
    inside_box_y = question.get("image_y", default_y)
    page_x = IMAGE_FRAME_X + inside_box_x
    page_y = IMAGE_FRAME_Y + inside_box_y


    current_picture_label = tk.Label(quiz_page, image=quiz_photo,
        background=ANSWER_COLOR)
    current_picture_label.place(x=page_x, y=page_y,
        width=image_width,
        height=image_height)
    current_picture_label.lift()


def show_multi_choice_buttons(question):
    """sets each multi choice buttons textand click event handler
    from question's answers, resets colours, places on screen and
    hides true/false questions.
    """
    answer_button_1.config(text=question["answers"][0],
        command=answer_1_clicked,
        state="normal")
    answer_button_2.config(text=question["answers"][1],
        command=answer_2_clicked,
        state="normal")
    answer_button_3.config(text=question["answers"][2],
        command=answer_3_clicked,
        state="normal")
    answer_button_4.config(text=question["answers"][3],
        command=answer_4_clicked,
        state="normal")
    answer_button_1.config(bg=ANSWER_COLOR)
    answer_button_2.config(bg=ANSWER_COLOR)
    answer_button_3.config(bg=ANSWER_COLOR)
    answer_button_4.config(bg=ANSWER_COLOR)
    answer_button_1.place(x=34, y=160, width=264, height=105)
    answer_button_2.place(x=34, y=285, width=264, height=105)
    answer_button_3.place(x=320, y=401, width=264, height=100)
    answer_button_4.place(x=320, y=511, width=264, height=100)
    true_button.place_forget()
    false_button.place_forget()


def show_true_false_buttons():
    """ resets true/false buttons colours and click handlers, places
    them on screen, and hides the multi choice answer buttons.
    """
    true_button.config(command=true_clicked, state="normal",
        bg=ANSWER_COLOR)
    false_button.config(command=false_clicked, state="normal",
        bg=ANSWER_COLOR)
    true_button.place(x=34, y=160, width=264, height=230)
    false_button.place(x=320, y=400, width=264, height=210)

    answer_button_1.place_forget()
    answer_button_2.place_forget()
    answer_button_3.place_forget()
    answer_button_4.place_forget()


def load_question(question_number):
    """reset state and display the question at the given index.
    Updates the question counter, clears any previous
    selections, sets the question text and image, and shows the
    right kind of answer buttons for the question's type.
    """
    global current_question_number
    global selected_answer_1, selected_answer_2
    global selected_answer_3, selected_answer_4
    global selected_tf_answer, question_has_been_answered

    current_question_number = question_number
    question = quiz_questions[question_number]
    question_count_label.config(
        text=str(question_number + 1) + "/"
        + str(QUESTIONS_PER_QUIZ))
    answer_feedback_label.config(text="", fg=BACKGROUND_COLOR)

    selected_answer_1 = False
    selected_answer_2 = False
    selected_answer_3 = False
    selected_answer_4 = False
    selected_tf_answer = None
    question_has_been_answered = False

    label_question.config(text=question["question"])
    show_question_image(question)
    fact_text_label.config(text="")

    if question["type"] == "multi":
        show_multi_choice_buttons(question)
    else:
        show_true_false_buttons()

    skip_next_button.config(text="Skip",
        command=skip_next_clicked,
        state="normal")


def has_made_a_selection():
    """return true if the current question has any answer set."""
    question = quiz_questions[current_question_number]
    if question["type"] == "multi":
        return (selected_answer_1 or selected_answer_2
            or selected_answer_3 or selected_answer_4)
    else:
        return selected_tf_answer is not None


def update_skip_next_button_text():
    """switch the skip/next button's label based on selection"""
    if question_has_been_answered:
        return
    if has_made_a_selection():
        skip_next_button.config(text="Next")
    else:
        skip_next_button.config(text="Skip")


def answer_1_clicked():
    """toggle whether multi choice answer one is selected."""
    global selected_answer_1
    if question_has_been_answered:
        return
    if selected_answer_1:
        selected_answer_1 = False
        answer_button_1.config(bg=ANSWER_COLOR)
    else:
        selected_answer_1 = True
        answer_button_1.config(bg=SELECTED_COLOR)
    update_skip_next_button_text()


def answer_2_clicked():
    """toggle whether multi choice answer two is selected."""
    global selected_answer_2
    if question_has_been_answered:
        return
    if selected_answer_2:
        selected_answer_2 = False
        answer_button_2.config(bg=ANSWER_COLOR)
    else:
        selected_answer_2 = True
        answer_button_2.config(bg=SELECTED_COLOR)
    update_skip_next_button_text()


def answer_3_clicked():
    """toggle whether multi choice answer three is selected."""
    global selected_answer_3
    if question_has_been_answered:
        return
    if selected_answer_3:
        selected_answer_3 = False
        answer_button_3.config(bg=ANSWER_COLOR)
    else:
        selected_answer_3 = True
        answer_button_3.config(bg=SELECTED_COLOR)
    update_skip_next_button_text()


def answer_4_clicked():
    """toggle whether multi choice answer four is selected."""
    global selected_answer_4
    if question_has_been_answered:
        return
    if selected_answer_4:
        selected_answer_4 = False
        answer_button_4.config(bg=ANSWER_COLOR)
    else:
        selected_answer_4 = True
        answer_button_4.config(bg=SELECTED_COLOR)
    update_skip_next_button_text()


def true_clicked():
    """select true as the answer to true/false question."""
    global selected_tf_answer
    if question_has_been_answered:
        return
    selected_tf_answer = True
    true_button.config(bg=SELECTED_COLOR)
    false_button.config(bg=ANSWER_COLOR)
    update_skip_next_button_text()


def false_clicked():
    """select false as the answer to true/false question."""
    global selected_tf_answer
    if question_has_been_answered:
        return
    selected_tf_answer = False
    false_button.config(bg=SELECTED_COLOR)
    true_button.config(bg=ANSWER_COLOR)
    update_skip_next_button_text()


def evaluate_multi_choice_answer(question):
    """colours the multi choice buttons and mark the question.
    every correct butons turns green and incorrect selections red.
    all 4 buttons get disabled.
    """
    correct_list = question["correct"]
    button_1_should_be_correct = 1 in correct_list
    button_2_should_be_correct = 2 in correct_list
    button_3_should_be_correct = 3 in correct_list
    button_4_should_be_correct = 4 in correct_list

    if button_1_should_be_correct:
        answer_button_1.config(bg=CORRECT_COLOR)
    elif selected_answer_1:
        answer_button_1.config(bg=WRONG_COLOR)
    answer_button_1.config(state="disabled")

    if button_2_should_be_correct:
        answer_button_2.config(bg=CORRECT_COLOR)
    elif selected_answer_2:
        answer_button_2.config(bg=WRONG_COLOR)
    answer_button_2.config(state="disabled")

    if button_3_should_be_correct:
        answer_button_3.config(bg=CORRECT_COLOR)
    elif selected_answer_3:
        answer_button_3.config(bg=WRONG_COLOR)
    answer_button_3.config(state="disabled")

    if button_4_should_be_correct:
        answer_button_4.config(bg=CORRECT_COLOR)
    elif selected_answer_4:
        answer_button_4.config(bg=WRONG_COLOR)
    answer_button_4.config(state="disabled")

    if selected_answer_1 != button_1_should_be_correct:
        return False
    if selected_answer_2 != button_2_should_be_correct:
        return False
    if selected_answer_3 != button_3_should_be_correct:
        return False
    if selected_answer_4 != button_4_should_be_correct:
        return False
    return True


def evaluate_true_false_answer(question):
    """colours the true/false buttons and mark the question.
    every correct butons turns green and incorrect selections red.
    all 4 buttons get disabled.
    """
    correct_answer = question["correct"]
    if correct_answer is True:
        true_button.config(bg=CORRECT_COLOR)
        if selected_tf_answer is False:
            false_button.config(bg=WRONG_COLOR)
    else:
        false_button.config(bg=CORRECT_COLOR)
        if selected_tf_answer is True:
            true_button.config(bg=WRONG_COLOR)
    true_button.config(state="disabled")
    false_button.config(state="disabled")
    return selected_tf_answer == correct_answer


def evaluate_answer():
    """Mark the current question, update the score and record it.
    gives to the multi choice or true/false evaluator
    depending on the question type, updates the running score
    and feedback label, shows the fun fact, and gives the
    result to answer_record for the results page.
    """
    global final_score, question_has_been_answered
    question = quiz_questions[current_question_number]
    if question["type"] == "multi":
        answered_correctly = evaluate_multi_choice_answer(
            question)
    else:
        answered_correctly = evaluate_true_false_answer(
            question)
    if answered_correctly:
        final_score = final_score + QUESTION_VALUE
        answer_feedback_label.config(text="+1",
            fg=CORRECT_COLOR)
    else:
        answer_feedback_label.config(text="+0",
            fg=WRONG_COLOR)
    fact_text_label.config(text=question["fact"])
    question_has_been_answered = True
    skip_next_button.config(text="Continue", state="normal")

    answer_record.append((question.get("name",
        question["question"]),
        answered_correctly))


def go_to_next_question():
    """goes to the next question, or show results if done."""
    next_question_number = current_question_number + 1
    if next_question_number == QUESTIONS_PER_QUIZ:
        show_results_page()
    else:
        load_question(next_question_number)


def skip_next_clicked():
    """Handles skip/next/continue button.
    evaluates answer if one selected, records skip
    if nothing was clicks, or moves to next question
    if question already answered.
    """
    skip_next_button.config(state="disabled")
    if question_has_been_answered:
        go_to_next_question()
    elif has_made_a_selection():
        evaluate_answer()
    else:
        question = quiz_questions[current_question_number]
        answer_record.append((question.get(
            "name", question["question"]), False))
        go_to_next_question()


def build_answer_list():
    """builds the results page's list of answered questions."""
    for widget in frame_answer_list.winfo_children():
        widget.destroy()


    entry_height = 48
    entry_gap = 4
    y_position = 8


    for index, (name, was_correct) in enumerate(
            answer_record, start=1):
        entry_color = (CORRECT_COLOR if was_correct
            else WRONG_COLOR)
        entry_label = tk.Label(
            frame_answer_list,
            text=str(index) + ". " + name,
            bg=entry_color, fg="black",
            font="lexend 12 bold", anchor="w",
            justify="left", wraplength=250)
        entry_label.place(x=8, y=y_position, width=258,
            height=entry_height)
        y_position += entry_height + entry_gap


def show_results_page():
    """Hide the quiz page and display the final results page,
    finds out score, filld summary label and list of answers.
    """
    quiz_page.place_forget()


    total_possible_score = QUESTIONS_PER_QUIZ * QUESTION_VALUE
    if final_score >= COMPREHENSIVE_MIN:
        score = "Comprehensive"
        score_message = "Awesome job!"
    elif final_score >= PROFICENT_MIN:
        score = "Proficient"
        score_message = "Great work!"
    elif final_score >= ADEQUATE_MIN:
        score = "Adequate"
        score_message = "Good effort!"
    else:
        score = "Limited"
        score_message = "Better luck next time!"
    result_title_label.config(text="Your score is " + score)
    result_score_label.config(
        text="The player got " + str(final_score) + "/"
        + str(total_possible_score)
        + " questions right! " + score_message)
    build_answer_list()
    results_page.place(x=0, y=0, width=624, height=728)


def begin_quiz():
    """Start a new quiz attempt from the beginning page. picks
    10 random quesrions, resets score and answer records, shows
    question one.
    """
    global quiz_questions, current_question_number
    global final_score, answer_record

    quiz_questions = random.sample(QUESTIONS,
        QUESTIONS_PER_QUIZ)
    current_question_number = 0
    final_score = 0
    answer_record = []
    begin_page.place_forget()
    results_page.place_forget()
    quiz_page.place(x=0, y=0, width=624, height=728)
    load_question(0)


#creates and places begin button
begin_button = tk.Button(begin_page, text="Begin Quiz!",
    height=3, width=28,
    highlightthickness=2,
    highlightbackground="black",
    highlightcolor="black",
    font="Lexend 24 bold", bg=ANSWER_COLOR,
    command=begin_quiz)
begin_button.place(x=38, y=560)

root.mainloop()


